Decentralized Cybersecurity Midterm Project — SVG conversion

Source: Decentralized_Cybersecurity_Midterm_Project.docx
Conversion: DOCX -> LibreOffice PDF -> pdftocairo SVG
Output: 26 page-level SVG files.

Important: this is a rendered/vector conversion, not a semantic reconstruction of the DOCX. Text is commonly encoded through SVG glyph definitions, so searching the SVG XML for visible phrases may not find the words directly.
